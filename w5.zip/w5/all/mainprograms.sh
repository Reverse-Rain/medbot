# in run.sh
python3 receive.py
python3 test.py
