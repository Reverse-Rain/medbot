import telebot

# Create the bot instance
bot_token = "token"
bot = telebot.TeleBot(bot_token)


